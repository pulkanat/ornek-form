-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 10, 2011 at 12:33 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `codeign`
--

-- --------------------------------------------------------

--
-- Table structure for table `deneme`
--

CREATE TABLE IF NOT EXISTS `deneme` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isim` varchar(20) NOT NULL,
  `soyad` varchar(20) NOT NULL,
  `adres` text NOT NULL,
  `telefon` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `deneme`
--

INSERT INTO `deneme` (`id`, `isim`, `soyad`, `adres`, `telefon`) VALUES
(1, 'gf', 'hg', 'jh', 'df'),
(2, 'gf', 'gfds', 'sfdg', 'gfds'),
(3, '', '', '', ''),
(4, 'egeg', 'fdfe', 'dgfklsm', 'mdfkslafds'),
(5, '', '', '', ''),
(6, 'fds', 'fds', 'fdsfs', 'fdgfd'),
(7, 'fdsf', 'sdfsdf', 'dsagg', 'ggdsgs'),
(8, 'fds', 'fds', 'dfs', 'fds'),
(9, 'vc', '', 'vcx', ''),
(10, '', '', 'vcxvc', ''),
(11, 'fdsafsa', 'fdsafasdf', 'fdsafdsa', '34214321');

-- --------------------------------------------------------

--
-- Table structure for table `musteri`
--

CREATE TABLE IF NOT EXISTS `musteri` (
  `musteri_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `musteri_ad` varchar(20) NOT NULL,
  `musteri_soyad` varchar(20) NOT NULL,
  `musteri_kimlik_no` varchar(11) NOT NULL,
  `musteri_vergi_dairesi` varchar(20) NOT NULL,
  `musteri_bolge` varchar(20) NOT NULL,
  `musteri_tel_gsm` int(11) NOT NULL,
  `musteri_tel_ev` int(11) NOT NULL,
  PRIMARY KEY (`musteri_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin5 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `musteri`
--

INSERT INTO `musteri` (`musteri_id`, `musteri_ad`, `musteri_soyad`, `musteri_kimlik_no`, `musteri_vergi_dairesi`, `musteri_bolge`, `musteri_tel_gsm`, `musteri_tel_ev`) VALUES
(1, 'ali', 'beb', '4532534', 'gfdgf', 'sizin ora', 4144532, 456563),
(2, 'bjkbknk', 'bhkbjhb', '657789', 'bhujjhb', 'bhjbkhb', 67896, 7890798),
(4, 'kamil', 'cekelek', '2341', 'fdsf', 'fdsfa', 4324, 432423),
(5, 'kamil', 'cekelek', '4234', 'fdsaf', 'fdsf', 4321, 4321),
(6, 'kamil', 'cekelek', '4234', 'fdsaf', 'fdsf', 4321, 4321),
(7, 'fdfds', 'fdsf', '432', 'fdsf', 'fdsffsd', 3442, 423424),
(8, 'fdsfds', 'fdsfdsf', '3242', '432432', '4fsdfs', 43242, 43234),
(10, 'Deli', 'mahmut', '123', 'Bakırköy', 'Bizim oralı', 123, 123),
(11, 'Deli', 'mahmut', '123', 'Bakırköy', 'Bizim oralı', 123, 123);

-- --------------------------------------------------------

--
-- Table structure for table `ornek`
--

CREATE TABLE IF NOT EXISTS `ornek` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isim` varchar(20) NOT NULL,
  `soyad` varchar(20) NOT NULL,
  `eposta` varchar(30) NOT NULL,
  `eposta2` varchar(30) NOT NULL,
  `tel` int(10) NOT NULL,
  `ek_bilgi` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=202 ;

--
-- Dumping data for table `ornek`
--

INSERT INTO `ornek` (`id`, `isim`, `soyad`, `eposta`, `eposta2`, `tel`, `ek_bilgi`) VALUES
(1, 'memo', 'can', 'ehu@mehu', 'kah@keh', 432424, 'simdilik yok'),
(3, 'fdsfs', 'fdsfds', 'ewrw@yahoc.com', 'fds@fds.com', 213131, ''),
(4, 'fdsfs', 'fdsfds', 'ewrw@yahoc.com', 'fds@fds.com', 213131, ''),
(5, 'fdsafsadfa', 'gfdsgdsgds', 'de@dddde.com', 'dfsfds@sirket1.com', 213131, ''),
(8, 'dfsf', 'fdsfd', 'rew@df.com', 'fddsf@df.com', 123131, ''),
(9, 'dfsf', 'fdsfd', 'rew@df.com', 'fddsf@df.com', 123131, ''),
(10, 'dfsf', 'fdsfd', 'rew@df.com', 'fddsf@df.com', 123131, ''),
(14, 'fds', 'fds', 'fds@dfs.com', 'dsf@cofd.com', 21321, ''),
(16, 'fdsfs', 'fdsfds', 'ewrw@yahoc.com', 'fds@fds.com', 213131, ''),
(17, 'fdsfs', 'fdsfds', 'ewrw@yahoc.com', 'fds@fds.com', 213131, ''),
(18, 'can', 'cem', 'de@dddde.com', 'fd@dfdfd.com', 9807097, ''),
(19, 'fds', 'fdsfds', 'fdsf@dfss.com', 'fdsfs@mds.com', 3232434, ''),
(20, 'eheu', 'hehfd', 'dfs@medf.com', 'dfsfds@dfs.com', 233432, ''),
(201, 'ehugfdsg', 'gfsgsd', 'dsaf@gdsbv.com', 'fdasfa@sirket2.com', 5324, ''),
(200, 'ali', 'veli', 'kahkeh@gmail.com', 'muhasebe@sirket1.com', 3353535, ''),
(198, 'fdsfsgdfsg', 'fdshdhdf', 'de@dddde.com', 'dsaf@sirket1.com', 1235324, ''),
(38, 'fdsgds', 'gssdfgdsg', 'dfs@gfds.com', 'dsaf@sirket1.com', 213, ''),
(39, 'bvcccx', 'bvcxbx', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123532, ''),
(40, 'fdhfghh', 'khkgljh', 'bvc@gfds.com', 'dfsfds@sirket1.com', 1235324, ''),
(41, 'dfsafasd', 'gdsfgdsgds', 'dfs@gfds.com', 'dfsfds@sirket1.com', 53453246, ''),
(44, 'bvcccx', 'bvcxbx', 'bvc@gfds.com', 'fdsgs@dscv.com', 123532, ''),
(102, 'lkjlj', 'lkjljm', 'bvc@gfds.com', 'cdf@dfsd.com', 54353453, ''),
(101, 'lkj', 'lkjl', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(47, 'bvcccx', 'bvcxbx', 'bvc@gfds.com', 'fdsgs@dscv.com', 123532, ''),
(48, 'bvcccx', 'bvcxbx', 'bvc@gfds.com', 'fdsgs@dscv.com', 123532, ''),
(49, 'bvcccx', 'bvcxbx', 'bvc@gfds.com', 'fdsgs@dscv.com', 123532, ''),
(53, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(54, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(56, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(57, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(58, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(65, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(66, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(67, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(69, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(70, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(71, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(73, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(74, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(75, 'fdsfsd', 'gdsss', 'dsgsd@gds.com', 'sgdsf@ccv.com', 2353543, ''),
(181, 'fdsafj', 'ggdsgh', 'bvc@gfds.com', 'fds.fdf@sirket1.com', 6535, ''),
(79, 'bvcccx', 'bvcxbx', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123532, ''),
(80, 'bvcccx', 'bvcxbx', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123532, ''),
(81, 'bvcccx', 'bvcxbx', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123532, ''),
(82, 'fdsfs', 'fdsfd', 'dfsaf@sgds.com', 'fdsasda@csafds.com', 432532445, ''),
(83, 'fdsfs', 'fdsfd', 'dfsaf@sgds.com', 'fdsasda@csafds.com', 432532445, ''),
(84, 'fdsfs', 'fdsfs', 'fds@dfs.com', 'fdsasda@csafds.com', 432532445, ''),
(85, 'fdsfs', 'fdsfs', 'fds@dfs.com', 'fdsasda@csafds.com', 432532445, ''),
(86, 'fdsfs', 'fdsfs', 'fds@dfs.com', 'fdsasda@csafds.com', 432532445, ''),
(88, 'dfs', 'fdsfsfff', 'fsda@dfsf.com', 'dfds@fdsfs.com', 2341, ''),
(89, 'altan', 'turel', 'a@yahoo.com', 'a@t.com', 505, ''),
(90, 'fdshhb', 'fdsfdsf', 'dsfsf@sagds.com', 'dsgdsss@gsfds.com', 34214121, ''),
(91, 'gdsdsf', 'gfdsggggg', 'dfs@gfds.com', 'fdsfa@fdsgsd.com', 31421341, ''),
(92, 'gdsdsfa', 'gfdsggggga', 'dfs@gfds.com', 'fdsfa@fdsgsd.com', 31421341, ''),
(93, 'gdsdsfaf', 'gfdsgggggaf', 'dfs@gfds.com', 'fdsfa@fdsgsd.com', 31421341, ''),
(94, 'gdsdsfaff', 'gfdsgggggaff', 'dfs@gfds.com', 'fdsfa@fdsgsd.com', 31421341, ''),
(95, 'rte', 'tre', 'gfd@fsd.com', 'cdf@dfsd.com', 421315, ''),
(96, 'rtee', 'tree', 'gfd@fsd.com', 'cdf@dfsd.com', 421315, ''),
(97, 'rteee', 'treee', 'gfd@fsd.com', 'cdf@dfsd.com', 421315, ''),
(98, 'rteeee', 'treeee', 'gfd@fsd.com', 'cdf@dfsd.com', 421315, ''),
(99, 'rteeeee', 'treeeee', 'gfd@fsd.com', 'cdf@dfsd.com', 421315, ''),
(100, 'fdsfdsdd', 'bvcdd', 'de@dddde.com', 'dfds@fdsfs.com', 123131, ''),
(103, 'lkjljf', 'lkjljmf', 'bvc@gfds.com', 'cdf@dfsd.com', 54353453, ''),
(104, 'gfd', 'gfd', 'dfs@medf.com', 'dfds@fdsfs.com', 202, ''),
(105, 'fmjk', 'ngnk', 'bvc@gfds.com', 'dfds@fdsfs.com', 123532, ''),
(106, 'jmh', 'mjhm', 'kbgm@mdksl.com', 'dfds@fdsfs.com', 123532, ''),
(107, 'jmhtt', 'mjhmtt', 'kbgm@mdksl.com', 'dfds@fdsfs.com', 123532, ''),
(108, 'nh', 'mj', 'de@dddde.com', 'cdf@dfsd.com', 123532, ''),
(109, 'bg', 'bgn', 'dfs@gfds.com', 'dfds@fdsfs.com', 123532, ''),
(110, 'bgb', 'bgnb', 'dfs@gfds.com', 'dfds@fdsfs.com', 123532, ''),
(111, 'bgbv', 'bgnbv', 'dfs@gfds.com', 'dfds@fdsfs.com', 123532, ''),
(112, 'jku', 'kju', 'dfs@medf.com', 'dfds@fdsfs.com', 1234567, ''),
(113, 'jkul', 'kjul', 'dfs@medf.com', 'dfds@fdsfs.com', 1234567, ''),
(114, 'fdsfg', 'hhj', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(115, 'fdsfgl', 'hhjl', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(116, 'fdsfgll', 'hhjll', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(117, 'fdsfglll', 'hhjlll', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(118, 'fdsfgllll', 'hhjllll', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(119, 'fdsfglllll', 'hhjlllll', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(120, 'fdsfgllllll', 'hhjllllll', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(121, 'fdsfglllllll', 'hhjlllllll', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(122, 'ny', 'ny', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123131, ''),
(123, 'nyt', 'tuu', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123131, ''),
(124, 'nun', 'nuym', 'de@dddde.com', 'dfds@fdsfs.com', 202, ''),
(125, 'nunl', 'nuyml', 'de@dddde.com', 'dfds@fdsfs.com', 202, ''),
(126, 'nunll', 'nuymll', 'de@dddde.com', 'dfds@fdsfs.com', 202, ''),
(127, 'nunlll', 'nuymlll', 'de@dddde.com', 'dfds@fdsfs.com', 202, ''),
(128, 'nunllll', 'nuymllll', 'de@dddde.com', 'dfds@fdsfs.com', 202, ''),
(129, 'nunlllll', 'lnuymllll', 'de@dddde.com', 'dfds@fdsfs.com', 202, ''),
(130, 'nunllllll', 'lnuymlllll', 'de@dddde.com', 'dfds@fdsfs.com', 202, ''),
(131, 'btb', 'btbt', 'de@dddde.com', 'dfsfds@dfs.com', 1234567, ''),
(132, 'btbl', 'btbtl', 'de@dddde.com', 'dfsfds@dfs.com', 1234567, ''),
(133, 'btbll', 'btbtll', 'de@dddde.com', 'dfsfds@dfs.com', 1234567, ''),
(134, 'btblll', 'btbtlll', 'de@dddde.com', 'dfsfds@dfs.com', 1234567, ''),
(135, 'btbllll', 'lll', 'de@dddde.com', 'dfsfds@dfs.com', 1234567, ''),
(136, 'fghj', 'fhj', 'de@dddde.com', 'dfds@fdsfs.com', 123532, ''),
(137, 'fghjj', 'fhjj', 'de@dddde.com', 'dfds@fdsfs.com', 123532, ''),
(138, 'fghjjh', 'fhjjh', 'de@dddde.com', 'dfds@fdsfs.com', 123532, ''),
(139, 'fghjjhhj', 'fhjjhjk', 'de@dddde.com', 'dfds@fdsfs.com', 123532, ''),
(140, 'fghjjhhjl', 'fhjjhjkl', 'de@dddde.com', 'dfds@fdsfs.com', 123532, ''),
(141, 'nht', 'nht', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(142, 'nhtnh', 'nhtnh', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(143, 'nhtnhll', 'nhtnhll', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(144, 'fdsfgj', 'jjk', 'bvc@gfds.com', 'dfds@fdsfs.com', 1234567, ''),
(145, 'nytj', 'jny', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(146, 'nytja', 'jnya', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(147, 'nytjaa', 'jnyaa', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(148, 'begsd', 'gsdds', 'dfs@gfds.com', 'dfds@fdsfs.com', 123131, ''),
(149, 'nrh', 'ngf', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123131, ''),
(150, 'nrha', 'ngfa', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123131, ''),
(151, 'nrhaa', 'ngfaa', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123131, ''),
(152, 'nrhaaa', 'ngfaaa', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123131, ''),
(153, 'ndh', 'ndn', 'bvc@gfds.com', 'dfds@fdsfs.com', 123532, ''),
(154, 'btrnr', 'nhtnhy', 'de@dddde.com', 'cdf@dfsd.com', 123131, ''),
(155, 'hytrnhr', 'nhyrtn', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(156, 'berngr', 'nhrten', 'nh@gfdgs.com', 'fdsgsd@gfs.com', 342235, ''),
(157, 'asdgsd', 'bgdbh', 'bvc@gfds.com', 'cdf@dfsd.com', 123131, ''),
(158, 'ggdsfhgd', 'hghdh', 'de@dddde.com', 'dfsdcc@gfdgd.com', 1234567, ''),
(159, 'gsdfns', 'nhfdn', 'bvc@gfds.com', 'cdf@dfsd.com', 202, ''),
(160, 'btr', 'bry', 'de@dddde.com', 'dfds@fdsfs.com', 123131, ''),
(161, 'btrbe', 'berb', 'bvc@gfds.com', 'dfds@fdsfs.com', 123131, ''),
(162, 'bge', 'bbehf', 'de@dddde.com', 'dfsdcc@gfdgd.com', 1234567, ''),
(163, 'vwervgw', 'vgwwwrb', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123131, ''),
(164, 'benbn', 'nhre', 'de@dddde.com', 'dfsdcc@gfdgd.com', 123131, ''),
(165, 'btrg', 'beb', 'dfs@medf.com', 'dfds@fdsfs.com', 123131, ''),
(166, 'vrewv', 'vgwevr', 'dfs@medf.com', 'dfsdcc@gfdgd.com', 123532, ''),
(167, 'bbgdg', 'bdgbd', 'de@dddde.com', 'dfds@fdsfs.com', 123131, ''),
(168, 'gbebe', 'gbetg', 'bvc@gfds.com', 'dfsdcc@gfdgd.com', 1234567, ''),
(169, 'vtrvw', 'btr', 'de@dddde.com', 'cdf@dfsd.com', 1234567, ''),
(170, 'bthrnn', 'hnen', 'de@dddde.com', 'cdf@dfsd.com', 123131, ''),
(171, 'bthrbt', 'hbryh', 'bvc@gfds.com', 'dfds@fdsfs.com', 1234567, ''),
(172, 'gtryr', 'hyrth', 'de@dddde.com', 'dfds@fdsfs.com', 1234567, ''),
(173, 'gtbrtge', 'btgb', 'de@dddde.com', 'dfds@fdsfs.com', 1235324, ''),
(174, 'hrtnr', 'nhyrtnht', 'dfs@gfds.com', 'dfds@fdsfs.com', 123532, ''),
(175, 'brtgb', 'bgtreb', 'bvc@gfds.com', 'cdf@dfsd.com', 1234567, ''),
(176, 'gbwe', 'brttt', 'bvc@gfds.com', 'dfds@fdsfs.com', 1234567, ''),
(177, 'bttrw', 'tbrewtg', 'dfs@gfds.com', 'cdf@dfsd.com', 123532, ''),
(178, 'bbtg', 'btgtr', 'bvc@gfds.com', 'dfds@fdsfs.com', 1234567, ''),
(179, 'bgrtg', 'bgtbtge', 'de@dddde.com', 'dfds@fdsfs.com', 202, ''),
(180, 'fds', 'fdsaf', 'bvc@gfds.com', 'cdf@dfsd.com', 123131, ''),
(182, 'gfdsgds', 'gfsdgs', 'gfdsgs@dfsaf.com', 'fsadf@sirket1.com', 3241, ''),
(183, 'gmk', 'oldfsa', 'fdsa@cdvs.com', 'dsaf@sirket1.com', 534262, ''),
(184, 'gfdsssss', 'gfsgsd', 'bvc@gfds.com', 'dfsfds@sirket1.com', 21321, ''),
(185, 'gfdsg', 'bdgbd', 'de@dddde.com', 'dfsfds@sirket1.com', 452, ''),
(186, 'gfsd', 'gfds', 'bvc@gfds.com', 'dfsfds@sirket1.com', 2341, ''),
(187, 'btbll', 'beb', 'dfsaf@sgds.com', 'dfsfds@sirket1.com', 4321, ''),
(188, 'bbgdg', 'beb', 'de@dddde.com', 'dfsfds@sirket1.com', 233432, ''),
(189, 'gfdsg', 'gdsfgs', 'bvc@gfds.com', 'dfsfds@sirket1.com', 213, ''),
(190, 'gsg', 'rtw', 'de@dddde.com', 'dfsfds@sirket1.com', 43214321, ''),
(191, 'fdsagdsf', 'gfsdgs', 'bvc@gfds.com', 'dfsfds@sirket1.com', 21321, ''),
(192, 'gfdsgdfs', 'gfdsgds', 'de@dddde.com', 'dfsfds@sirket1.com', 5345, ''),
(193, 'gdsfdsgds', 'hghdhgd', 'de@dddde.com', 'dfsfds@sirket1.com', 563, ''),
(194, 'fdsgds', 'hghd', 'de@dddde.com', 'dfsfds@sirket1.com', 5324532, ''),
(195, 'gsfds', 'hgghd', 'dfs@gfds.com', 'dfsfds@sirket1.com', 645, ''),
(196, 'hfdhj', 'jhjf', 'bvc@gfds.com', 'dfsfds@sirket1.com', 213, ''),
(197, 'ytyeh', 'jfjj', 'de@dddde.com', 'dfsfds@sirket1.com', 213, '');

-- --------------------------------------------------------

--
-- Table structure for table `siparis`
--

CREATE TABLE IF NOT EXISTS `siparis` (
  `siparis_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `musteri_id` int(10) unsigned NOT NULL,
  `siparis_tur` varchar(20) CHARACTER SET latin5 NOT NULL,
  `siparis_cesit` varchar(20) CHARACTER SET latin5 NOT NULL,
  `siparis_viol_tur` varchar(20) CHARACTER SET latin5 NOT NULL,
  `siparis_yetistirme` varchar(20) CHARACTER SET latin5 NOT NULL,
  `siparis_kayit` datetime NOT NULL COMMENT 'siparis tarihi',
  `siparis_teslim` datetime NOT NULL COMMENT 'teslim tarihi',
  `siparis_ekim` datetime NOT NULL COMMENT 'ekim tarihi',
  `siparis_odeme` varchar(20) NOT NULL COMMENT 'odeme sekli',
  `siparis_adet` int(10) unsigned NOT NULL,
  PRIMARY KEY (`siparis_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `siparis`
--

INSERT INTO `siparis` (`siparis_id`, `musteri_id`, `siparis_tur`, `siparis_cesit`, `siparis_viol_tur`, `siparis_yetistirme`, `siparis_kayit`, `siparis_teslim`, `siparis_ekim`, `siparis_odeme`, `siparis_adet`) VALUES
(5, 3, 'hkjh', 'jklj', '', 'jjkljl', '2028-01-10 18:22:28', '2028-01-10 18:22:28', '2028-01-10 18:22:28', 'para', 5675),
(4, 1, 'fdsafdsa', 'fdsafsa', '', 'gfdsg', '2028-01-10 18:19:48', '2028-01-10 18:19:48', '2028-01-10 18:19:48', 'fdsaf', 5432),
(6, 3, 'fds', 'fdsafa', '', 'dfsafsa', '2010-01-28 18:24:37', '2021-11-08 18:24:37', '2010-01-28 18:24:37', '10-01-28 18:24:37', 231),
(7, 3, 'fds', 'fdsafa', 'fewr', 'dfsafsa', '2010-01-28 18:24:37', '2010-01-28 18:24:37', '2021-11-13 18:24:37', '10-01-28 18:24:37', 231),
(8, 3, 'fefe', 'sds', 'fefesdf', 'fdsafds', '2010-02-03 23:14:29', '2010-05-05 23:14:29', '2010-05-03 23:14:29', 'turk lirasi', 4),
(9, 3, 'domates', 'bahce', 'şeşelek', 'sera', '2010-02-04 00:00:29', '2010-06-06 00:00:29', '2010-06-04 00:00:29', 'fransız frangı', 11),
(10, 9, 'fdsaf', 'fdsf', 'fdsfsd', 'fdsfsd', '2010-02-04 00:44:13', '2010-02-04 00:44:13', '2010-02-04 00:44:13', 'fsdafsd', 43),
(11, 10, 'fdsaf', 'fdsf', 'fdsfsd', 'fdsfsd', '2010-02-04 00:44:13', '2010-02-04 00:44:13', '2010-02-04 00:44:13', 'fsdafsd', 43),
(12, 10, 'fdsaf', 'fdsf', 'fdsfsd', 'fdsfsd', '2010-02-04 00:44:13', '2010-02-04 00:44:13', '2010-02-04 00:44:13', 'fsdafsd', 43),
(13, 10, 'fdsaf', 'fdsf', 'fdsfsd', 'fdsfsd', '2010-02-04 00:44:13', '2010-02-04 00:44:13', '2010-02-04 00:44:13', 'fsdafsd', 43);

-- --------------------------------------------------------

--
-- Table structure for table `tohum`
--

CREATE TABLE IF NOT EXISTS `tohum` (
  `tohum_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tohum_adi` varchar(20) NOT NULL,
  `tohum_firma` varchar(20) NOT NULL,
  `tohum_dagitici` varchar(20) NOT NULL COMMENT 'dagitici firma',
  `tohum_lot_no` int(10) unsigned NOT NULL,
  `tohum_fatura_no` int(10) unsigned NOT NULL,
  `tohum_fatura_tarihi` date NOT NULL,
  `tohum_miktar` int(11) NOT NULL COMMENT 'alinan miktar',
  PRIMARY KEY (`tohum_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin5 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tohum`
--

